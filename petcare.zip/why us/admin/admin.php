<?php
// Admin Page to View Booking Requests (admin_view.php)

// Database connection
$servername = "localhost";  // Your database server
$username = "root";         // Your database username
$password = "";             // Your database password
$dbname = "petcare";        // Your database name

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Tables to fetch data from
$tables = [
    'boarding_bookings', 
    'grooming_bookings', 
    'pathology_bookings', 
    'training_bookings', 
    'veterinarian_bookings', 
    'walking_service_bookings',
    'contact_form' // Add this table for contact form submissions
];

$allBookings = [];

foreach ($tables as $table) {
    // Custom query for contact_form table
    if ($table === 'contact_form') {
        $sql = "SELECT id, name, email, message, submitted_at FROM contact_form";
    } else {
        $sql = "SELECT * FROM $table";
    }

    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $row['table_name'] = $table; // Add the table name for identification
            $allBookings[] = $row;
        }
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin View Bookings</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2 class="mb-4">Admin - View Booking Requests</h2>
        <?php if (!empty($allBookings)): ?>
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Table Name</th>
                        <th>Booking ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Pet Type</th>
                        <th>Requirements</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Price</th>
                        <th>Message</th>
                        <th>Submitted At</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($allBookings as $booking): ?>
                        <tr>
                            <td><?= htmlspecialchars($booking['table_name']); ?></td>
                            <td><?= htmlspecialchars($booking['id'] ?? 'N/A'); ?></td>
                            <td><?= htmlspecialchars($booking['name'] ?? 'N/A'); ?></td>
                            <td><?= htmlspecialchars($booking['email'] ?? 'N/A'); ?></td>
                            <td><?= htmlspecialchars($booking['phone'] ?? 'N/A'); ?></td>
                            <td><?= htmlspecialchars($booking['pet_type'] ?? 'N/A'); ?></td>
                            <td><?= htmlspecialchars($booking['requirements'] ?? 'N/A'); ?></td>
                            <td><?= htmlspecialchars($booking['preferred_date'] ?? 'N/A'); ?></td>
                            <td><?= htmlspecialchars($booking['preferred_time'] ?? 'N/A'); ?></td>
                            <td><?= htmlspecialchars($booking['total_price'] ?? 'N/A'); ?></td>
                            <td><?= htmlspecialchars($booking['message'] ?? 'N/A'); ?></td>
                            <td><?= htmlspecialchars($booking['submitted_at'] ?? 'N/A'); ?></td>
                            <td>
                                <?php if ($booking['table_name'] !== 'contact_form'): ?>
                                  
                                    <a href="delete_booking.php?id=<?= $booking['id']; ?>&table=<?= $booking['table_name']; ?>" class="btn btn-danger btn-sm">Delete</a>
                                <?php else: ?>
                                    <a href="delete_booking.php?id=<?= $booking['id']; ?>&table=<?= $booking['table_name']; ?>" class="btn btn-danger btn-sm">Delete</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No bookings found.</p>
        <?php endif; ?>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>

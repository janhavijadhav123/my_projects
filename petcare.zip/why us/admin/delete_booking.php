<?php
// delete_booking.php
if (isset($_GET['id']) && isset($_GET['table'])) {
    $id = intval($_GET['id']);
    $table = $_GET['table'];

    // Database connection
    $conn = new mysqli("localhost", "root", "", "petcare");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Delete booking from the table
    $sql = "DELETE FROM $table WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        echo "Booking deleted successfully.";
    } else {
        echo "Error: " . $conn->error;
    }

    $conn->close();
    header("Location: admin.php");
    exit;
}
?>

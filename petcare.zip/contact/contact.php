<?php
// Database connection settings
$servername = "localhost"; // Database server
$username = "root";        // Database username
$password = "";            // Database password
$dbname = "petcare";       // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];

// Validate inputs
if (empty($name) || empty($email) || empty($message)) {
    die("All fields are required!");
}

// Prepare and bind SQL statement to prevent SQL injection
$stmt = $conn->prepare("INSERT INTO contact_form (name, email, message) VALUES (?, ?, ?)");
if (!$stmt) {
    error_log("SQL Error: " . $conn->error);
    die("Error preparing statement: " . $conn->error);
}
$stmt->bind_param("sss", $name, $email, $message);

// Execute the query
if ($stmt->execute()) {
    echo "Thank you! Your message has been submitted.";
} else {
    echo "Error: " . $stmt->error;
}

// Close connection
$stmt->close();
$conn->close();
?>

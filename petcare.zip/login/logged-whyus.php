<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pet Care Center - Why Us</title>
    <link rel="stylesheet" href="w.css">
</head>
<body>

  <header>
    <h1>PAWSITIVE PET CARE </h1>
    <p>"Where tails wag and whiskers wander."</p>
</header>

<nav>
<a href="../login/logged-home.php">HOME</a>
        <a href="../login/logged-services.php">SERVICES</a>
        <a href="../login/logged-contact.php">CONTACT</a>
        <a href="../login/logged-whyus.php">WHY US</a>
        
</nav>

    <section id="why-us">
        <h2>Why Choose Our Pet Care Center?</h2>

        <div class="reason">
            <img class="img" src="./w2.jpg" alt="Experience Icon">
           
        </div>


    </section>

    <section class="section">
        <div class="card">
          <div class="card-text">
            <h2>QUALITY TRUSTED PROFESSIONALS</h2>
            <p>We bring you the best pet care experts with assured third party background checks and high-performance standards.
              Book now and choose from a trusted network of providers committed to delivering the highest quality service, always.</p>
          </div>
          <img src="./professionals.png" alt="Image Description 1">
        </div>
    
        <div class="card">
          <div class="card-text">
            <h2>REVIEWS AND FEEDBACK</h2>
            <p>Your opinion matters! Whether you are a pet parent or service expert, we take extra care to ensure a trustworthy platform wherein all parties can share their ratings and honest feedback.
               Experience the best pet care services at PawPurrfect. Book now!</p>
          </div>
          <img src="./feedback.png" alt="Image Description 2">
        </div>
      </section>

      <section class="pet-care-section">
        <div class="pet-image">
          <img src="./delivery.png" alt="Pet care image">
        </div>
        <div class="delivery-info">
          <h2>ASSURED DELIVERY</h2>
          <p>One stop for all your pet service needs! Book your desired pet service on the PawPurrfect app in just a few clicks and get assured grooming, walking, sitting, boarding, training and veterinary services delivered by our network of experts at your doorstep.
          </p>
        </div>
      </section>

      <section class="section">
        <div class="card">
          <div class="card-text">
            <h2>SERVICE AT YOUR DOOR STEP</h2>
            <p>Looking for quality pet care services at your doorstep? Book reliable and trusted professionals on PawPurrfect to enjoy a wide range of services for your dogs and cats in the comfort of home!.</p>
          </div>
          <img src="./doorstep.png" alt="Image Description 1">
        </div>
    
        <div class="card">
          <div class="card-text">
            <h2>TRANSPARENT PRICING</h2>
            <p>For every service booked on the PawPurrfect app we assure you the guarantee of transparent, up-front pricing. No more clauses in fine prints or hidden costs.  .</p>
          </div>
          <img src="./pricing.png" alt="Image Description 2">
        </div>
      </section>

</body>
</html>

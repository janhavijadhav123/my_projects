\<?php
// Database connection settings
$servername = "localhost"; // Replace with your database server
$username = "root";        // Replace with your database username
$password = "";            // Replace with your database password
$dbname = "petcare";       // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Sanitize input data
    $email = htmlspecialchars($_POST['email']);
    $password = htmlspecialchars($_POST['password']);

    // Query the database for the user
    $stmt = $conn->prepare("SELECT id, name, password FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        // Verify the password
        if (password_verify($password, $user['password'])) {
            // Start session and set session variables
            session_start();
            $_SESSION['user_id'] = $user['id'];           // Store user ID in session
            $_SESSION['user_name'] = $user['name'];       // Store user name in session
            $_SESSION['user_email'] = $email;            // Store user email in session

            // Redirect to a dashboard or home page
            header("Location: logged-home.php");
            exit();
        } else {
            echo "Incorrect password. Please try again.";
        }
    } else {
        echo "No user found with this email. Please sign up.";
    }

    // Close the statement
    $stmt->close();
}

// Close the database connection
$conn->close();
?>

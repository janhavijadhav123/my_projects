<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./contact.css">
</head>
<body>
    <header>
        <h1>PAWSITIVE PET CARE </h1>
        <p>"Where tails wag and whiskers wander."</p>
    </header> 

<nav>
    <a href="../login/logged-home.php">HOME</a>
    <a href="../login/logged-services.php">SERVICES</a>
    <a href="">CONTACT</a>
    <a href="../login/logged-whyus.php">WHY US</a>
      
  </nav>

    <section class="contact-form">
        <h2>Contact Us</h2>
        <p>Have questions or need assistance? Reach out to us!</p>
    
        <div class="contact-details">
            <p><strong>Phone:</strong> 8789165481 <a href="tel:+91 8789165481">call</a></p>
            <p><strong>Email:</strong> Pawsitive_Pet_Care@gmail.com <a href="mailto:kartikphad@gmail.com "> mail</a></p>
        </div>
    
        <form action="#" method="post">
            <label for="name">Your Name:</label>
            <input type="text" id="name" name="name" required>
    
            <label for="email">Your Email:</label>
            <input type="email" id="email" name="email" required>
    
            <label for="message">Your Message:</label>
            <textarea id="message" name="message" rows="4" required></textarea>
    
            <button type="submit" class="btn">Submit</button>
        </form>
    </section>

    




















</body>
</html>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Pet Services</title>
    <link rel="stylesheet" href="123.css">
    
</head>

<body>
  
  
  
  <header>
    <h1>PAWSITIVE PET CARE </h1>
    <p>"Where tails wag and whiskers wander."</p>
</header>

<nav>
    <a href="../home page/123.html">HOME</a>
    <a href="../services-all/123.html">SERVICES</a>
    <a href="../contact/contact.html">CONTACT</a>
    <a href="../why us/w.html">WHY US</a>
   s    <li> <a href="###"> Welcome, <?php 
             session_start();
                echo isset($_SESSION['user_email']) ? $_SESSION['user_email'] : ''; 
                ?>
             </a></li>
    
</nav>
    

    <div class="Home-image">

       <img src="./372497215805780.png" alt="" width="100%">


    </div>


    <section class="pet-section">
        <div class="overlay">
          <h1>CARING | CONVENIENT | TRUSTED</h1>
          <p>YOUR PET SERVICE EXPERT AT YOUR DOORSTEP<br>
            Find the right help for your cats and dogs at home.<br>
            We are just a click away!</p>
        </div>
      </section>

      <div class="service-button">
              <a href="../login/login.html">  <button class="button-77" role="button"> WANT TO BOOK A SERVICE REQUEST..?</button></a> 
      </div>


          

       <div class="card-collection">


          <div class="card">
            <img class="card-img-top" src="./marketplace.png" alt="Card image cap">
            <div class="card-body">
              <p class="card-text">First of its kind e-marketplace with a selection of verified vendors to suit individual needs..</p>
            </div>
          </div>

          <div class="card" style="width: 18rem;">
            <img class="card-img-top" src="./quality logo.png" alt="Card image cap">
            <div class="card-body">
              <p class="card-text">Best pet care experts with assured third party background checks and high-performance standards..</p>
            </div>
          </div>

          <div class="card" style="width: 18rem;">
            <img class="card-img-top" src="./service logo.png" alt="Card image cap">
            <div class="card-body">
          <p class="card-text">Top quality pet care services brought to the comfort of your home by trusted professionals</p>
            </div>
          </div> 

    </div>

  
  
        

</body>
</html>






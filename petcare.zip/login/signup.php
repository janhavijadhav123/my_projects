<?php
// Database connection settings
$servername = "localhost"; // Replace with your database server
$username = "root";        // Replace with your database username
$password = "";            // Replace with your database password
$dbname = "petcare";       // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Sanitize input data
    $name = htmlspecialchars($_POST['name']);
    $mobileNo = htmlspecialchars($_POST['mobileNo']);
    $email = htmlspecialchars($_POST['email']);
    $password = htmlspecialchars($_POST['password']);
    $confirmPassword = htmlspecialchars($_POST['confirmPassword']);

    // Check if passwords match
    if ($password !== $confirmPassword) {
        echo "Passwords do not match!";
        exit();
    }

    // Hash the password for security
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Prepare and bind the SQL statement
    $stmt = $conn->prepare("INSERT INTO users (name, mobile_no, email, password) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $mobileNo, $email, $hashedPassword);

    // Execute the statement and check for success
    if ($stmt->execute()) {
        echo "Registration successful!";
    } else {
        if ($conn->errno === 1062) { // Handle duplicate email error
            echo "Error: Email already registered.";
        } else {
            echo "Error: " . $conn->error;
        }
    }

    // Close the statement and connection
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Pet Services</title>
    <link rel="stylesheet" href="logged-service.css">
</head>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap')
    </style>
<body>
    <header>
        <h1>PAWSITIVE PET CARE </h1>
        <p>"Where tails wag and whiskers wander."</p>
    </header>

    <nav>
        <a href="../login/logged-home.php">HOME</a>
        <a href="">SERVICES</a>
        <a href="../login/logged-contact.php">CONTACT</a>
        <a href="../login/logged-whyus.php">WHY US</a>
        
    </nav>

  

    <section id="services">
        <div class="service-container">
            <div class="service-box">
                <!-- Content for Service 1 -->
                <img src="./groom.png" alt="Service 1">
                <h3> <a href="../6service/grooming/groomm.html"><button id="buttons">GROOMING</button></a> </h3>
                <p>"Pamper your pets with love and style at our grooming oasis!".</p>
            </div>

            <div class="service-box">
                <!-- Content for Service 2 -->
                <img src="./walk.png" alt="Service 2">
                <h3> <a href="../6service/walk/walking.html"><button id="buttons">WALKING</button></a> </h3>
                <p>"Stroll, wag, repeat – our pet walking service makes tails and trails happy!".</p>
            </div>
        </div>

        <div class="service-container">
            <div class="service-box">
                <!-- Content for Service 3 -->
                <img src="./train.png" alt="Service 3">
                <h3> <a href="../6service/training/training.html"><button id="buttons">TRAINING</button></a> </h3>
                <p>"Unlocking your pet's potential, one command at a time."</p>
            </div>

            <div class="service-box">
                <!-- Content for Service 4 -->
                <img src="board.png" alt="Service 4">
                <h3> <a href="../6service/boarding/boarding.html"><button id="buttons">BOARDING</button></a> </h3>
                <p>"A home away from home for your furry family member."</p>
            </div>
        </div>
        
         <div class="service-container">
            <div class="service-box">
                <!-- Content for Service 3 -->
                <img src="./VE.png" alt="Service 3">
                <h3> <a href="../6service/veterinarian/vet.html"><button id="buttons">VACCINATION</button></a> </h3>
                <p>"Vaccination: the key to a purr-fectly healthy pet."</p>
            </div>

            <div class="service-box">
                <!-- Content for Service 4 -->
                <img src="./vaccine.png" alt="Service 4">
                <h3> <a href="../6service/pathology/Pathology Test.html"><button id="buttons">PATHOLOGY TEST</button></a> </h3>
                <p>"Pathology expertise for your pet's peace of mind."</p>
            </div>
        </div>
    </section>

        

</body>
</html>
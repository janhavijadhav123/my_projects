<?php
// Database connection
$servername = "localhost";  // Your database host
$username = "root";         // Your database username
$password = "";             // Your database password (usually empty for localhost)
$dbname = "petcare";        // Your database name

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$pincode = $_POST['pincode'];
$preferred_date = $_POST['date'];
$hours = $_POST['hours'];
$minutes = $_POST['minutes'];
$ampm = $_POST['ampm'];
$pet_type = $_POST['pet'];
$requirements = json_encode($_POST['requirements']);  // Convert array to JSON
$total_price = 0;

// Calculate total price based on selected requirements
$pet_prices = [
    "cat" => [
        "Bathing and blow-drying" => 15,
        "Hair trimming and styling" => 20,
        "Nail trimming and filing" => 10,
        "Ear cleaning and plucking" => 8
    ],
    "dog" => [
        "Bathing and blow-drying" => 20,
        "Hair trimming and styling" => 25,
        "Nail trimming and filing" => 15,
        "Ear cleaning and plucking" => 10
    ]
];

foreach ($_POST['requirements'] as $requirement) {
    $total_price += $pet_prices[$pet_type][$requirement] ?? 0;
}

// Format time in 24-hour format
if ($ampm == "PM" && $hours != 12) {
    $hours += 12;
} elseif ($ampm == "AM" && $hours == 12) {
    $hours = 0;
}

$preferred_time = sprintf("%02d:%02d:00", $hours, $minutes);

// Insert data into the database
$sql = "INSERT INTO grooming_bookings (name, email, phone, address, pincode, preferred_date, preferred_time, pet_type, requirements, total_price, description)
        VALUES ('$name', '$email', '$phone', '$address', '$pincode', '$preferred_date', '$preferred_time', '$pet_type', '$requirements', '$total_price', '".$_POST['description']."')";

if ($conn->query($sql) === TRUE) {
    // Redirect to home page with success message
    echo "<script>alert('Booking successfully submitted!'); window.location.href='thankyou.php';</script>";
    exit;
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close connection
$conn->close();
?>

<?php
// Database connection
$servername = "localhost";
$username = "root"; // Change this to your database username
$password = ""; // Change this to your database password
$dbname = "petcare"; // Change this to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Collecting form data
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$pincode = $_POST['pincode'];
$preferred_date = $_POST['date'];
$preferred_time = $_POST['hours'] . ':' . $_POST['minutes'] . ' ' . $_POST['ampm'];
$pet = $_POST['pet'];
$walk_duration = $_POST['requirements'][0]; // Assuming only one option is selected
$description = $_POST['description'];

// Calculating total price
$pet_price = $pet === 'dog' ? 25 : 20; // Dog = 25, Cat = 20
$walk_price = 0;
switch ($walk_duration) {
    case 'walk-30 Min':
        $walk_price = 10;
        break;
    case 'walk-45 Min':
        $walk_price = 15;
        break;
    case 'walk-1 hour':
        $walk_price = 20;
        break;
}

// Calculate total price
$total_price = $pet_price + $walk_price;

// Prepare SQL statement to insert the data
$sql = "INSERT INTO walking_service_bookings (name, email, phone, address, pincode, preferred_date, preferred_time, pet, walk_duration, total_price, description)
        VALUES ('$name', '$email', '$phone', '$address', '$pincode', '$preferred_date', '$preferred_time', '$pet', '$walk_duration', '$total_price', '$description')";

// Check if the insertion was successful
if ($conn->query($sql) === TRUE) {
    // Redirect to home page with success message
    echo "<script>alert('Booking successfully submitted! Total price: ₹$total_price'); window.location.href='thankyou.php';</script>";
    exit;
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the connection
$conn->close();
?>

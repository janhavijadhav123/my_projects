<?php
// Database connection
$servername = "localhost";
$username = "root"; // Change this to your database username
$password = ""; // Change this to your database password
$dbname = "petcare"; // Change this to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Collecting form data
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$pincode = $_POST['pincode'];
$preferred_date = $_POST['date'];
$preferred_time = $_POST['hours'] . ':' . $_POST['minutes'] . ' ' . $_POST['ampm'];
$pet = $_POST['pet'];
$requirements = json_encode($_POST['requirements']); // Storing multiple requirements as JSON
$description = $_POST['description'];

// Calculating total price
$pet_price = $pet === 'dog' ? 500 : 300; // Dog = 500, Cat = 300
$total_price = $pet_price;

// Add the price for selected requirements
foreach ($_POST['requirements'] as $requirement) {
    switch ($requirement) {
        case 'Routine check-ups and vaccinations':
            $total_price += 1500;
            break;
        case 'Diagnosis and treatment of illnesses and injuries':
            $total_price += 2500;
            break;
        case 'Dental care, including cleanings and extractions':
            $total_price += 2000;
            break;
        case 'Prescription medications and dietary management':
            $total_price += 1000;
            break;
        case 'Laboratory testing, including blood work and urinalysis':
            $total_price += 3000;
            break;
    }
}

// Prepare SQL statement to insert the data
$sql = "INSERT INTO veterinarian_bookings (name, email, phone, address, pincode, preferred_date, preferred_time, pet, requirements, description, total_price)
        VALUES ('$name', '$email', '$phone', '$address', '$pincode', '$preferred_date', '$preferred_time', '$pet', '$requirements', '$description', '$total_price')";

// Check if the insertion was successful
if ($conn->query($sql) === TRUE) {
    // Redirect to home page with success message
    echo "<script>alert('Booking successfully submitted! Total price: ₹$total_price'); window.location.href='thankyou.php';</script>";
    exit;
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the connection
$conn->close();
?>

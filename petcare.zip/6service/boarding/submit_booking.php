<?php
// Submit Booking Script (submit_booking.php)

// Function to sanitize inputs
function sanitize_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and assign form values to variables
    $name = sanitize_input($_POST['name']);
    $email = sanitize_input($_POST['email']);
    $phone = sanitize_input($_POST['phone']);
    $address = sanitize_input($_POST['address']);
    $pincode = sanitize_input($_POST['pincode']);
    $date = sanitize_input($_POST['date']);
    $hours = sanitize_input($_POST['hours']);
    $minutes = sanitize_input($_POST['minutes']);
    $ampm = sanitize_input($_POST['ampm']);
    $pet = sanitize_input($_POST['pet']);
    $requirements = sanitize_input($_POST['requirements']);
    $description = sanitize_input($_POST['description']);

    // Combine hours, minutes, and AM/PM to create a time format (e.g., "2:30 PM")
    $time = $hours . ':' . str_pad($minutes, 2, '0', STR_PAD_LEFT) . ' ' . $ampm;

    // Calculate the total price based on pet and requirements (optional, you can also retrieve prices from a database)
    $price = 0;
    if ($pet == "cat") {
        if ($requirements == "board-Daily") $price = 15;
        else if ($requirements == "board-Weekly") $price = 80;
        else if ($requirements == "board-Monthly") $price = 300;
    } else if ($pet == "dog") {
        if ($requirements == "board-Daily") $price = 20;
        else if ($requirements == "board-Weekly") $price = 100;
        else if ($requirements == "board-Monthly") $price = 350;
    }

    // Database connection
    $servername = "localhost";  // Your database server
    $username = "root";         // Your database username
    $password = "";             // Your database password
    $dbname = "petcare";        // Your database name

    // Create a connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and bind SQL query to insert data into the service_bookings table
    $stmt = $conn->prepare("INSERT INTO boarding_bookings (name, email, phone, address, pincode, preferred_date, preferred_time, pet_type, requirements, total_price, description) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssssssss", $name, $email, $phone, $address, $pincode, $date, $time, $pet, $requirements, $price, $description);

    // Execute the query
    if ($stmt->execute()) {
        // Redirect to thank-you page after successful booking
        echo "<script>alert('Your booking is successful!'); window.location.href='thankyou.php';</script>";
        exit;
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close connection
    $stmt->close();
    $conn->close();
} else {
    echo "Invalid request.";
}
?>

<?php
// Add your database connection logic here
error_reporting(E_ALL); ini_set('display_errors', 1);
$servername = "localhost";
$username = "root";
$password = "";
$database = "petcare";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve data from the 'Booking' table
$sql = "SELECT * FROM Booking";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
    <!-- Include any additional styles or scripts as needed -->
</head>
<body>
    <h2>Booking Data</h2>
    <table border="1">
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Address</th>
            <th>Pincode</th>
            <th>Date</th>
            <th>Requirements</th>
            <th>Description</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>" . $row["name"] . "</td>
                        <td>" . $row["email"] . "</td>
                        <td>" . $row["phone"] . "</td>
                        <td>" . $row["address"] . "</td>
                        <td>" . $row["pincode"] . "</td>
                        <td>" . $row["date"] . "</td>
                        <td>" . $row["requirements"] . "</td>
                        <td>" . $row["description"] . "</td>
                    </tr>";
            }
        } else {
            echo "<tr><td colspan='8'>No data found</td></tr>";
        }
        ?>
    </table>

    <?php
    // Close the database connection
    $conn->close();
    ?>
</body>
</html>
